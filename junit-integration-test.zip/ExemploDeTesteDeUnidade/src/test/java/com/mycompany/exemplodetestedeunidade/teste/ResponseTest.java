/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.teste;

import com.mycompany.exemplodetestedeunidade.utils.Response;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author 189435
 */
public class ResponseTest {
    
    private Response res;
    
    @Before
    public void init() {

        res = new Response();

    }
    
    @Test
    public void getStatus() {
    	
        res.setStatus(true);
        Assert.assertEquals(true, res.getStatus());

        res.setStatus(false);
        Assert.assertEquals(false, res.getStatus());
        
    }
    
    @Test
    public void getMessage() {
        
        res.setMessage("Ok");
        Assert.assertEquals("Ok", res.getMessage());   
        
        res.setMessage("Erro");
        Assert.assertEquals("Erro", res.getMessage());        

    }
    
}
