/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.teste;

import com.mycompany.exemplodetestedeunidade.bean.Pessoa;
import com.mycompany.exemplodetestedeunidade.repository.PessoaRepository;
import com.mycompany.exemplodetestedeunidade.utils.Response;
import java.util.Date;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author 189435
 */
public class PessoaRepositoryTest {

    private PessoaRepository pessoaRepo;

    @Before
    public void init() {

        pessoaRepo = new PessoaRepository();

    }

    @Test
    public void getAll() {

        List<Pessoa> pessoaList = pessoaRepo.getAll();
        
        pessoaRepo.save(new Pessoa("nome", "exemplo1@email.com", "123456", new Date()));
        
        pessoaList = pessoaRepo.getAll();
        
        Assert.assertEquals(1, pessoaList.size());

        pessoaRepo.delete(pessoaList.get(0).getId());
        
    }

    @Test
    public void getByIdNotFound() {

        Pessoa res = pessoaRepo.getPessoaById("S");

        Assert.assertEquals(res.getId(), null);

    }

    @Test
    public void getByIdFound() {

        Response res = pessoaRepo.save(new Pessoa("nome", "exemplo2@email.com", "123456", new Date()));

        Pessoa pv = (Pessoa) res.getResponse().get(0);

        Pessoa p = pessoaRepo.getPessoaById(pv.getId());

        Assert.assertNotEquals(null, p.getId());

        pessoaRepo.delete(p.getId());
        
    }

    @Test
    public void saveInvalidPessoa() {
        
        Response res = pessoaRepo.save(new Pessoa("nome", "exemplo@email.com", "1234", new Date()));
     
        Assert.assertEquals( false, res.getStatus() );
        Assert.assertEquals( true, res.getMessage().contains("senha") );
        
        res = pessoaRepo.save(new Pessoa("nome", "exemplo", "123456", new Date()));
     
        Assert.assertEquals( false, res.getStatus() );
        Assert.assertEquals( true, res.getMessage().contains("e-mail") );
    
    }
    
    
    @Test
    public void saveValidPessoa() {
        
        Response res = pessoaRepo.save(new Pessoa("nome", "exemplo23@email.com", "123456", new Date()));
     
        Assert.assertEquals( true, res.getStatus() );
        Assert.assertEquals( true, res.getMessage().contains("Sucesso") );

        pessoaRepo.delete(( (Pessoa) res.getResponse().get(0)).getId());
        
    }

    @Test
    public void updateInvalidPessoa() {

        Pessoa invalidPessoa = new Pessoa();

        invalidPessoa.setId("tset");
        invalidPessoa.setEmail("123@email.io");
        invalidPessoa.setSenha("123456");
        
        Response p = pessoaRepo.update(invalidPessoa);

        Assert.assertEquals(false, p.getStatus() );
        Assert.assertEquals(true, p.getMessage().contains("ID não encontrado.") );
        
    }    
    
    @Test
    public void updateValidPessoa() {

    	Response res = pessoaRepo.save(new Pessoa("nome", "exemplo5@email.com", "123456", new Date()));
    	
        Response p = pessoaRepo.update(( (Pessoa) res.getResponse().get(0)));

        Assert.assertEquals(true, p.getStatus());
        Assert.assertEquals(true, p.getMessage().contains("Sucesso") );
        
        pessoaRepo.delete(( (Pessoa) res.getResponse().get(0)).getId());
        
    }    
    
    @Test
    public void deleteInvalidId() {
    	
        Pessoa validPessoa = new Pessoa();

        validPessoa.setId("INVALID");
    
        Response p = pessoaRepo.delete(validPessoa.getId());

        Assert.assertEquals(false, p.getStatus());
        Assert.assertEquals(true, p.getMessage().contains("ID não encontrado.") );
        
    }
    
    @Test
    public void deleteValidId() {
    	
        List<Pessoa> pessoaList = pessoaRepo.getAll();

        Pessoa validPessoa = new Pessoa();

        for (Pessoa p : pessoaList) {

            validPessoa.setId(p.getId());
            validPessoa.setEmail(p.getEmail());
            validPessoa.setSenha(p.getSenha());
            validPessoa.setDataNascimento(p.getDataNascimento());

            System.out.println("Pessoa ID: "+validPessoa.getId());
            Response res = pessoaRepo.delete(validPessoa.getId());

            Assert.assertEquals(true, res.getStatus() );
            Assert.assertEquals(true, res.getMessage().contains("Sucesso") );
            
        }

    }
    
}
