/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.teste;

import org.junit.Before;
import org.junit.Test;
import com.mycompany.exemplodetestedeunidade.utils.DatabaseConnection;
import java.sql.Connection;
import java.sql.SQLException;
import org.junit.Assert;

/**
 *
 * @author gabri
 */
public class DatabaseConnectionTest {
    
    private DatabaseConnection db;
    
    @Before
    public void makeData() {
    	
       db = new DatabaseConnection();
       
    }
    
    @Test()
    public void connectedSuccesfully() throws SQLException {
   
        Connection conn = db.connect();
        
        Assert.assertEquals(conn.isClosed(), false);
        
    }
    
    @Test()
    public void errorToConnect() throws SQLException {
        
        db = new DatabaseConnection("jdbc:mysql://localhost:3306", "test", "12345");

        Connection conn = db.connect();

        Assert.assertEquals(conn, null);
        
    }
    
}
