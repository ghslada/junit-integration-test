/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author 189435
 */
public class DatabaseConnection {
    
    private String url = "jdbc:mysql://localhost:3306";
    private String user = "convidado";
    private String password = "12345";

    private Connection conn;

    public DatabaseConnection(String url, String user, String password) {
        
        this.url = url;
        
        this.user = user;
        
        this.password = password;
        
        if ( conn == null ) {
        
            try {

                conn = DriverManager.getConnection(url, user, password);            
                                
            } catch(Exception e ) {
                
                System.out.println(e.getMessage());
                
            }
        
        }

    }
    
    public DatabaseConnection () {
       
        if ( conn == null ) {
        
            try {

                conn = DriverManager.getConnection(url, user, password);            
             
            } catch(SQLException e ) {
                
                System.out.println(e.getMessage());
                
            }
        
        }

    }
    
    public Connection connect() {

        try {
            
            if ( conn == null ) {
                
                conn = DriverManager.getConnection(url, user, password);
                
                System.out.println("Connected to the MySQL server successfully.");
                
            } else {
                
                if ( conn.isClosed() ) {
                    
                    conn = DriverManager.getConnection(url, user, password);

                    System.out.println("Connected to the MySQL server successfully.");

                } else {
                
                    System.out.println("Already connected to the MySQL server. Returning connection instance...");
    
                }
                
                return conn;
                
            }
            
        } catch (SQLException e) {
            
            System.out.println(e.getMessage());
            
        }

        return conn;
    }

    public String getUrl() {
        return url;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }
    
    
    
}
