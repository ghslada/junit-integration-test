/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade;

//import com.mycompany.exemplodetestedeunidade.teste.PessoaRepositoryTest;

import com.mycompany.exemplodetestedeunidade.bean.Pessoa;
import com.mycompany.exemplodetestedeunidade.repository.PessoaRepository;
import com.mycompany.exemplodetestedeunidade.utils.Response;

import java.util.Date;
import java.util.List;

// Java Program to Illustrate App File
 
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author 189435
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Main {

    // CONECTAR AO BANCO A CLASSE REPOSITORY
    public static void main(String[] args) {
		
    	SpringApplication.run(Main.class, args);
		
		PessoaRepository pr = new PessoaRepository();
		
		List<Pessoa> pl = pr.getAll();
        
		System.out.println(pl);
		
        Pessoa pes1 = new Pessoa();
 
        pes1.setId("10278e28-1a19-411f-9de0-557fa3a89ba2");
        pes1.setNome("Pessoa 123");
        pes1.setEmail("pessoa1@email.com");
        pes1.setSenha("123456");
        pes1.setDataNascimento(new Date());
	
        Response res = pr.save(pes1);

        System.out.println(res);        
       
        pes1 = pr.getPessoaByEmail(pes1.getEmail());
        
        pes1.setNome("Novo nome");
        
        Response res2 = pr.update(pes1);

		System.out.println(res2);        

		Response res3 = pr.delete(pes1.getId());
		
		System.out.println(res3);
		
    }
}
