/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.utils;

import java.util.List;

import org.hibernate.type.AnyType;

/**
 *
 * @author 189435
 */
public class Response {

    private Boolean status;
    private List<Object> response; 
    private String message;

    public List<Object> getResponse() {
		return response;
	}

	public void setResponse(List<Object> response) {
		this.response = response;
	}

	public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    @Override
    public String toString() {
    	return "{\"status\":"+status+",\"message\":"+message+",\"response\":"+response+"}";
    }

}
