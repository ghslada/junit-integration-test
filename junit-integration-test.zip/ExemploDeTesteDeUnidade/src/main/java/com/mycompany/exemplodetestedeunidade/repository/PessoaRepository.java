/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.repository;

import com.mycompany.exemplodetestedeunidade.bean.Pessoa;
import com.mycompany.exemplodetestedeunidade.utils.DatabaseConnection;
import com.mycompany.exemplodetestedeunidade.utils.Response;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.scheduling.annotation.Async;

/**
 *
 * @author 189435
 */
public class PessoaRepository {

    private Connection conn;
    private List<Pessoa> pessoaRepository;
    
    private Session session;
    
    public PessoaRepository() {

    	Configuration configuration =  new Configuration();
    	configuration.configure("hibernate.cfg.xml");
    	configuration.addAnnotatedClass(Pessoa.class);

  	    // Create Session Factory
  	    SessionFactory sessionFactory
  	      = configuration.buildSessionFactory();

  	    // Initialize Session Object
  	    session = sessionFactory.openSession();

        pessoaRepository = this.getAll();

        if ( conn == null ) {
            
            conn = new DatabaseConnection().connect();
            
        }

    }

    @SuppressWarnings("unchecked")
	public List<Pessoa> getAll() {
    	
//	  // Create Session Factory
//	  SessionFactory sessionFactory
//	      = configuration.buildSessionFactory();
//
//	  // Initialize Session Object
//	  Session session = sessionFactory.openSession();
//    	
	  String query = "from Pessoa";
       
	  pessoaRepository = (List<Pessoa>) session.createQuery(query).getResultList();
	  
	  return pessoaRepository;

    }

    public Pessoa getPessoaById(String id) {

        Pessoa pessoa = new Pessoa();
//
//  	    // Create Session Factory
//  	    SessionFactory sessionFactory
//  	      = configuration.buildSessionFactory();
//
//  	    // Initialize Session Object
//  	    Session session = sessionFactory.openSession();

        Pessoa pFromDB = (Pessoa) session.createQuery("from Pessoa where id = :id").
        setParameter("id", id).
        uniqueResult();

        if ( pFromDB == null ) {
        
        	System.out.println("ID da pessoa nao esta no DB");
            
        }
        else {

        	System.out.println(pFromDB);
        	System.out.println("ID da pessoa esta no DB");
            pessoa = pFromDB;
            
        }

        return pessoa;

    }


    public Pessoa getPessoaByEmail(String email) {

        Pessoa pessoa = new Pessoa();
//
//  	    // Create Session Factory
//  	    SessionFactory sessionFactory
//  	      = configuration.buildSessionFactory();
//
//  	    // Initialize Session Object
//  	    Session session = sessionFactory.openSession();
      	
   	    String query = "from Pessoa";

        Pessoa pFromDB = (Pessoa) session.createQuery("from Pessoa where email = :email").
        setParameter("email", email).
        uniqueResult();

        if ( pFromDB == null ) {
        
        	System.out.println("email da pessoa nao esta no DB");
            
        }
        else {

        	System.out.println(pFromDB);
        	System.out.println("email da pessoa esta no DB");
            pessoa = pFromDB;
            
        }

        return pessoa;

    }

    
    public Response save(Pessoa pessoa) {

        String uniqueID = UUID.randomUUID().toString();

        pessoa.setId(uniqueID);

        Response response = new Response();

        response.setStatus(true);

        response.setMessage("Sucesso ao salvar pessoa no banco de dados.");
        
//        pessoaRepository = this.getAll();
//      
        Pessoa pessoaExistenteNoBD = this.getPessoaByEmail(pessoa.getEmail());

        if ( pessoaExistenteNoBD.getEmail() != null ) {

            response.setStatus(false);

            response.setMessage("E-mail já existe no banco de dados.");

        }

        pessoaExistenteNoBD = this.getPessoaById(pessoa.getId());
        
        if ( pessoaExistenteNoBD.getId() != null ) {
        	
            response.setStatus(false);

            response.setMessage("Este ID já está em uso.");
            
        }
        
        if (pessoa.getEmail().length() < 10) {

            response.setStatus(false);

            response.setMessage("E-mail inválido. o endereço de e-mail precisa ter no mínimo 10 caracteres.");

        }

        if (pessoa.getSenha().length() < 6) {

            response.setStatus(false);

            response.setMessage("Senha inválida. A senha precisa ter no mínimo 6 caracteres.");

        }

        if (response.getStatus() == true) {
        	
            session.beginTransaction();
            // Here we have used
            // save() method of JPA
            session.save(pessoa);
    
            session.getTransaction().commit();
            
            List<Object> pList = new ArrayList<>();
            
            pList.add(pessoa);
            
            response.setResponse( pList );
            
            pessoaRepository.add(pessoa);

        }

        return response;

    }

    public Response update(Pessoa pessoa) {

        Response response = new Response();

        response.setStatus(false);

        response.setMessage("ID não encontrado.");

        if (pessoa.getEmail().length() < 10) {

            response.setStatus(false);

            response.setMessage("E-mail inválido. o endereço de e-mail precisa ter no mínimo 10 caracteres.");

        } else {

            if (pessoa.getSenha().length() < 6) {

                response.setStatus(false);

                response.setMessage("Senha inválida. A senha precisa ter no mínimo 6 caracteres.");

            } else {
                
            	System.out.println(pessoa.getId());
            	
            	Pessoa pessoaExistenteNoBD = this.getPessoaById(pessoa.getId());
        	
            	System.out.println(pessoaExistenteNoBD);
            	
                if ( pessoaExistenteNoBD.getId() == pessoa.getId() ) {

//                    pessoaExistenteNoBD.setNome(pessoa.getNome());
//
//                    pessoaExistenteNoBD.setSenha(pessoa.getSenha());
//
//                    pessoaExistenteNoBD.setDataNascimento(pessoa.getDataNascimento());


                    session.beginTransaction();
                    // Here we have used

                    session.saveOrUpdate(pessoa);
            
                    session.getTransaction().commit();
                    
                    response.setStatus(true);

                    response.setMessage("Sucesso ao editar dados da pessoa.");
                    
                    List<Object> res = new ArrayList<>();
                    
                    res.add(pessoa);
                    
                    response.setResponse( res );

                }

            }

        }

        return response;

    }

    public Response delete(String id) {

        Response response = new Response();

        response.setStatus(false);

        response.setMessage("ID não encontrado.");

        Pessoa pessoaExistenteNoBD = this.getPessoaById(id);
        
        if ( pessoaExistenteNoBD.getId() == id ) {

            session.beginTransaction();
            // Here we have used

        	session.createQuery("DELETE FROM Pessoa WHERE id = :id")
        		.setParameter("id", id)
        		.executeUpdate();
    
            session.getTransaction().commit();
        	
            response.setStatus(true);

            response.setMessage("Sucesso ao excluir pessoa.");
            
            List<Object> res = new ArrayList<>();
            
            res.add(pessoaExistenteNoBD);
            
            response.setResponse(res);

        }

        return response;

    }

}
