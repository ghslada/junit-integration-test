CREATE USER 'convidado'@'localhost' IDENTIFIED BY '12345';

GRANT ALL PRIVILEGES ON * . * TO 'convidado'@'localhost' WITH GRANT OPTION;

FLUSH PRIVILEGES;

CREATE DATABASE testdb;

USE testdb;

SHOW TABLES;

DROP TABLE pessoa;

CREATE TABLE pessoa (

	id varchar(500) primary key,
    nome varchar(5000),
    email varchar(150),
    senha varchar(150),
    data_nascimento date
    
);

SELECT * FROM pessoa;